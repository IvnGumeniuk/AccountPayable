﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Account_Payable1
{
    
    public partial class SearchVendor : Form
    {
        //public static string vendorname = "";
        public SearchVendor()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string query = " SELECT Vendor_ID, companyName, companyType, phone, email, country, city, address_ FROM TBL_VENDOR WHERE ("+
                "Vendor_ID LIKE '%{0}%'"+ searchV.Text.Trim() + " OR Vendor_ID LIKE '%{0}%')"+ searchV.Text.Trim();


            BindingSource bs = new BindingSource();
            bs.DataSource = dataGridView1.DataSource;
            bs.Filter = "[companyName] Like '%" + searchV.Text + "%'";
            dataGridView1.DataSource = bs;
        }

        private void SearchVendor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'accountsPayableDataSet1.TBL_VENDOR' table. You can move, or remove it, as needed.
            this.tBL_VENDORTableAdapter.Fill(this.accountsPayableDataSet1.TBL_VENDOR);

        }

        private void searchVendor_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //CreatePurchaseOrder cpo = new CreatePurchaseOrder();
            //if (!cpo.Activated)

        
                //cpo.Activate();
                CreatePurchaseOrder.vendorname = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            this.Close();
                
            //frm2.Activated += new EventHandler(frm2_Activated);
            //this.searchVendor_FormClosed += new FormClosedEventHandler(searchVendor_FormClosed);
            //setVendor();

        }
       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
     
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
