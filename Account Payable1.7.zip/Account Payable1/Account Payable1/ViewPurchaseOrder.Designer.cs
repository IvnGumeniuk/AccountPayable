﻿namespace Account_Payable1
{
    partial class ViewPurchaseOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.usernamelbl = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addresslbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.deliverydatelbl = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.createdatelbl = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.POID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.coaddresslbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.telelbl = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.emaillbl = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.employeeaddresslbl = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.employeetelelbl = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.employeeemaillbl = new System.Windows.Forms.Label();
            this.employeesurnamelbl = new System.Windows.Forms.Label();
            this.employeenamelbl = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.totallbl = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(769, 637);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 46);
            this.button1.TabIndex = 25;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(932, 637);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 46);
            this.button2.TabIndex = 26;
            this.button2.Text = "Delete";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.usernamelbl);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.addresslbl);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.deliverydatelbl);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.createdatelbl);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.POID);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(46, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(328, 186);
            this.panel2.TabIndex = 27;
            // 
            // usernamelbl
            // 
            this.usernamelbl.AutoSize = true;
            this.usernamelbl.Location = new System.Drawing.Point(157, 159);
            this.usernamelbl.Name = "usernamelbl";
            this.usernamelbl.Size = new System.Drawing.Size(97, 20);
            this.usernamelbl.TabIndex = 32;
            this.usernamelbl.Text = "usernameID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 159);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 20);
            this.label3.TabIndex = 31;
            this.label3.Text = "Created by:";
            // 
            // addresslbl
            // 
            this.addresslbl.AutoSize = true;
            this.addresslbl.Location = new System.Drawing.Point(184, 135);
            this.addresslbl.Name = "addresslbl";
            this.addresslbl.Size = new System.Drawing.Size(66, 20);
            this.addresslbl.TabIndex = 30;
            this.addresslbl.Text = "address";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 20);
            this.label1.TabIndex = 29;
            this.label1.Text = "Delivery Address:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(110, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 20);
            this.label17.TabIndex = 28;
            this.label17.Text = "notes";
            // 
            // deliverydatelbl
            // 
            this.deliverydatelbl.AutoSize = true;
            this.deliverydatelbl.Location = new System.Drawing.Point(157, 62);
            this.deliverydatelbl.Name = "deliverydatelbl";
            this.deliverydatelbl.Size = new System.Drawing.Size(75, 20);
            this.deliverydatelbl.TabIndex = 27;
            this.deliverydatelbl.Text = "dd/mm/yy";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(111, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 20);
            this.label15.TabIndex = 26;
            this.label15.Text = "terms";
            // 
            // createdatelbl
            // 
            this.createdatelbl.AutoSize = true;
            this.createdatelbl.Location = new System.Drawing.Point(157, 39);
            this.createdatelbl.Name = "createdatelbl";
            this.createdatelbl.Size = new System.Drawing.Size(75, 20);
            this.createdatelbl.TabIndex = 25;
            this.createdatelbl.Text = "dd/mm/yy";
            this.createdatelbl.Click += new System.EventHandler(this.createdatelbl_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(30, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 20);
            this.label13.TabIndex = 24;
            this.label13.Text = "Notes:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(30, 83);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 20);
            this.label12.TabIndex = 23;
            this.label12.Text = "Terms:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(29, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "Delivery Date:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "Created Date:";
            // 
            // POID
            // 
            this.POID.Location = new System.Drawing.Point(200, 9);
            this.POID.Name = "POID";
            this.POID.Size = new System.Drawing.Size(100, 26);
            this.POID.TabIndex = 20;
            this.POID.TextChanged += new System.EventHandler(this.POID_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 25);
            this.label5.TabIndex = 19;
            this.label5.Text = "Purchase Order:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.coaddresslbl);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.telelbl);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.emaillbl);
            this.panel1.Location = new System.Drawing.Point(393, 31);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 186);
            this.panel1.TabIndex = 33;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 8);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 20);
            this.label38.TabIndex = 31;
            this.label38.Text = "From:";
            // 
            // coaddresslbl
            // 
            this.coaddresslbl.AutoSize = true;
            this.coaddresslbl.Location = new System.Drawing.Point(127, 85);
            this.coaddresslbl.Name = "coaddresslbl";
            this.coaddresslbl.Size = new System.Drawing.Size(66, 20);
            this.coaddresslbl.TabIndex = 30;
            this.coaddresslbl.Text = "address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(41, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 20);
            this.label9.TabIndex = 29;
            this.label9.Text = "Address:";
            // 
            // telelbl
            // 
            this.telelbl.AutoSize = true;
            this.telelbl.Location = new System.Drawing.Point(150, 62);
            this.telelbl.Name = "telelbl";
            this.telelbl.Size = new System.Drawing.Size(80, 20);
            this.telelbl.TabIndex = 28;
            this.telelbl.Text = "telephone";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(64, 4);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(166, 25);
            this.label26.TabIndex = 19;
            this.label26.Text = "Company Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(41, 63);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 20);
            this.label22.TabIndex = 24;
            this.label22.Text = "Telephone: ";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(41, 42);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 20);
            this.label23.TabIndex = 23;
            this.label23.Text = "Email:";
            // 
            // emaillbl
            // 
            this.emaillbl.AutoSize = true;
            this.emaillbl.Location = new System.Drawing.Point(122, 42);
            this.emaillbl.Name = "emaillbl";
            this.emaillbl.Size = new System.Drawing.Size(46, 20);
            this.emaillbl.TabIndex = 26;
            this.emaillbl.Text = "email";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel3.Controls.Add(this.employeeaddresslbl);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Controls.Add(this.employeetelelbl);
            this.panel3.Controls.Add(this.label32);
            this.panel3.Controls.Add(this.label33);
            this.panel3.Controls.Add(this.employeeemaillbl);
            this.panel3.Controls.Add(this.employeesurnamelbl);
            this.panel3.Controls.Add(this.employeenamelbl);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Location = new System.Drawing.Point(739, 31);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(328, 186);
            this.panel3.TabIndex = 33;
            // 
            // employeeaddresslbl
            // 
            this.employeeaddresslbl.AutoSize = true;
            this.employeeaddresslbl.Location = new System.Drawing.Point(101, 135);
            this.employeeaddresslbl.Name = "employeeaddresslbl";
            this.employeeaddresslbl.Size = new System.Drawing.Size(66, 20);
            this.employeeaddresslbl.TabIndex = 44;
            this.employeeaddresslbl.Text = "address";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(15, 135);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 20);
            this.label30.TabIndex = 43;
            this.label30.Text = "Address:";
            // 
            // employeetelelbl
            // 
            this.employeetelelbl.AutoSize = true;
            this.employeetelelbl.Location = new System.Drawing.Point(124, 112);
            this.employeetelelbl.Name = "employeetelelbl";
            this.employeetelelbl.Size = new System.Drawing.Size(80, 20);
            this.employeetelelbl.TabIndex = 42;
            this.employeetelelbl.Text = "telephone";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(15, 113);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 20);
            this.label32.TabIndex = 40;
            this.label32.Text = "Telephone: ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(15, 92);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(58, 20);
            this.label33.TabIndex = 39;
            this.label33.Text = "Email:";
            // 
            // employeeemaillbl
            // 
            this.employeeemaillbl.AutoSize = true;
            this.employeeemaillbl.Location = new System.Drawing.Point(96, 92);
            this.employeeemaillbl.Name = "employeeemaillbl";
            this.employeeemaillbl.Size = new System.Drawing.Size(46, 20);
            this.employeeemaillbl.TabIndex = 41;
            this.employeeemaillbl.Text = "email";
            // 
            // employeesurnamelbl
            // 
            this.employeesurnamelbl.AutoSize = true;
            this.employeesurnamelbl.Location = new System.Drawing.Point(190, 65);
            this.employeesurnamelbl.Name = "employeesurnamelbl";
            this.employeesurnamelbl.Size = new System.Drawing.Size(71, 20);
            this.employeesurnamelbl.TabIndex = 38;
            this.employeesurnamelbl.Text = "surname";
            // 
            // employeenamelbl
            // 
            this.employeenamelbl.AutoSize = true;
            this.employeenamelbl.Location = new System.Drawing.Point(170, 42);
            this.employeenamelbl.Name = "employeenamelbl";
            this.employeenamelbl.Size = new System.Drawing.Size(49, 20);
            this.employeenamelbl.TabIndex = 37;
            this.employeenamelbl.Text = "name";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(15, 65);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(169, 20);
            this.label27.TabIndex = 36;
            this.label27.Text = "Employee Surname:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(15, 42);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(143, 20);
            this.label28.TabIndex = 35;
            this.label28.Text = "Employee Name:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(5, 7);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(34, 20);
            this.label37.TabIndex = 34;
            this.label37.Text = "To:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(45, 4);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(160, 25);
            this.label39.TabIndex = 33;
            this.label39.Text = "Vendor\'s Name";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(225, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "Vendor ID";
            // 
            // totallbl
            // 
            this.totallbl.AutoSize = true;
            this.totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totallbl.Location = new System.Drawing.Point(56, 646);
            this.totallbl.Name = "totallbl";
            this.totallbl.Size = new System.Drawing.Size(48, 25);
            this.totallbl.TabIndex = 35;
            this.totallbl.Text = "total";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(601, 637);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(136, 46);
            this.button3.TabIndex = 36;
            this.button3.Text = "Print";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(272, 637);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(73, 46);
            this.button4.TabIndex = 37;
            this.button4.Text = "<";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(353, 637);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(73, 46);
            this.button5.TabIndex = 38;
            this.button5.Text = ">";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(46, 224);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1022, 405);
            this.dataGridView1.TabIndex = 39;
            // 
            // ViewPurchaseOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 708);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.totallbl);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "ViewPurchaseOrder";
            this.Text = "View Purchase Order";
            this.Load += new System.EventHandler(this.ViewPurchaseOrder_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private AccountPayableDataSet accountPayableDataSet;
       // private AccountPayableDataSetTableAdapters.purchaseOrderTableAdapter purchaseOrderTableAdapter;
      //  private System.Windows.Forms.DataGridViewTextBoxColumn cHRNoteDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label deliverydatelbl;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label createdatelbl;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox POID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label usernamelbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label addresslbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label coaddresslbl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label telelbl;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label emaillbl;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label employeeaddresslbl;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label employeetelelbl;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label employeeemaillbl;
        private System.Windows.Forms.Label employeesurnamelbl;
        private System.Windows.Forms.Label employeenamelbl;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label totallbl;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.BindingSource accountsPayableDataSet1BindingSource;
        private AccountsPayableDataSet1 accountsPayableDataSet1;
        private System.Windows.Forms.BindingSource tBLPOITEMSBindingSource;
        private AccountsPayableDataSet1TableAdapters.TBL_PO_ITEMSTableAdapter tBL_PO_ITEMSTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn pOIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}