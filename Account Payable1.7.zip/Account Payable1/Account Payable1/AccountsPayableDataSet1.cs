﻿namespace Account_Payable1
{


    public partial class AccountsPayableDataSet1
    {
    }
}
namespace Account_Payable1 {
    
    
    public partial class AccountsPayableDataSet1 {
    }
}
namespace Account_Payable1 {
    
    
    public partial class AccountsPayableDataSet1 {
    }
}
namespace Account_Payable1 {
    
    
    public partial class AccountsPayableDataSet1 {
    }
}
namespace Account_Payable1 {
    
    
    public partial class AccountsPayableDataSet1 {
    }
}
namespace Account_Payable1 {
    
    
    public partial class AccountsPayableDataSet1 {
    }
}
