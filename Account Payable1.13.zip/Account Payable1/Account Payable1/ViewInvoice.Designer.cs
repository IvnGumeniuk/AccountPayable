﻿namespace Account_Payable1
{
    partial class ViewInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lblsurname = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblpoid = new System.Windows.Forms.LinkLabel();
            this.tBLINVOICEBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.accountsPayableDataSet1 = new Account_Payable1.AccountsPayableDataSet1();
            this.label40 = new System.Windows.Forms.Label();
            this.lblnotes = new System.Windows.Forms.Label();
            this.lblpay = new System.Windows.Forms.Label();
            this.lblcreated = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.invoicetxt = new System.Windows.Forms.TextBox();
            this.tBLINVOICEBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tBLINVOICEBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.approvecmd = new System.Windows.Forms.Button();
            this.tBLINVOICEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBL_INVOICETableAdapter = new Account_Payable1.AccountsPayableDataSet1TableAdapters.TBL_INVOICETableAdapter();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountsPayableDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(24, 841);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(56, 25);
            this.lbltotal.TabIndex = 46;
            this.lbltotal.Text = "Total";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(104, 186);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(66, 20);
            this.lbladdress.TabIndex = 44;
            this.lbladdress.Text = "address";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(17, 143);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(80, 20);
            this.label30.TabIndex = 43;
            this.label30.Text = "Address:";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Location = new System.Drawing.Point(126, 120);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(80, 20);
            this.lblphone.TabIndex = 42;
            this.lblphone.Text = "telephone";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(17, 121);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(103, 20);
            this.label32.TabIndex = 40;
            this.label32.Text = "Telephone: ";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(17, 100);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(58, 20);
            this.label33.TabIndex = 39;
            this.label33.Text = "Email:";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Location = new System.Drawing.Point(98, 100);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(46, 20);
            this.lblemail.TabIndex = 41;
            this.lblemail.Text = "email";
            // 
            // lblsurname
            // 
            this.lblsurname.AutoSize = true;
            this.lblsurname.Location = new System.Drawing.Point(192, 73);
            this.lblsurname.Name = "lblsurname";
            this.lblsurname.Size = new System.Drawing.Size(71, 20);
            this.lblsurname.TabIndex = 38;
            this.lblsurname.Text = "surname";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(172, 50);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(49, 20);
            this.lblname.TabIndex = 37;
            this.lblname.Text = "name";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(17, 73);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(169, 20);
            this.label27.TabIndex = 36;
            this.label27.Text = "Employee Surname:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(17, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(143, 20);
            this.label28.TabIndex = 35;
            this.label28.Text = "Employee Name:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(61, 6);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(160, 25);
            this.label39.TabIndex = 33;
            this.label39.Text = "Vendor\'s Name";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(225, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "Vendor ID";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.lblcity);
            this.panel1.Controls.Add(this.lblcountry);
            this.panel1.Controls.Add(this.lbladdress);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.lblphone);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.lblname);
            this.panel1.Controls.Add(this.lblsurname);
            this.panel1.Controls.Add(this.lblemail);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Location = new System.Drawing.Point(613, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(328, 207);
            this.panel1.TabIndex = 44;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(103, 167);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(66, 20);
            this.lblcity.TabIndex = 46;
            this.lblcity.Text = "address";
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Location = new System.Drawing.Point(103, 146);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.Size = new System.Drawing.Size(66, 20);
            this.lblcountry.TabIndex = 45;
            this.lblcountry.Text = "address";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 8);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(55, 20);
            this.label38.TabIndex = 31;
            this.label38.Text = "From:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.lblpoid);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.lblnotes);
            this.panel2.Controls.Add(this.lblpay);
            this.panel2.Controls.Add(this.lblcreated);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.invoicetxt);
            this.panel2.Location = new System.Drawing.Point(29, 43);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(328, 207);
            this.panel2.TabIndex = 41;
            // 
            // lblpoid
            // 
            this.lblpoid.AutoSize = true;
            this.lblpoid.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tBLINVOICEBindingSource3, "invoiceID", true));
            this.lblpoid.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tBLINVOICEBindingSource3, "POID", true));
            this.lblpoid.Location = new System.Drawing.Point(255, 168);
            this.lblpoid.Name = "lblpoid";
            this.lblpoid.Size = new System.Drawing.Size(57, 20);
            this.lblpoid.TabIndex = 34;
            this.lblpoid.TabStop = true;
            this.lblpoid.Text = "PO_ID";
            // 
            // tBLINVOICEBindingSource3
            // 
            this.tBLINVOICEBindingSource3.DataMember = "TBL_INVOICE";
            this.tBLINVOICEBindingSource3.DataSource = this.accountsPayableDataSet1;
            // 
            // accountsPayableDataSet1
            // 
            this.accountsPayableDataSet1.DataSetName = "AccountsPayableDataSet1";
            this.accountsPayableDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(86, 168);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(163, 20);
            this.label40.TabIndex = 33;
            this.label40.Text = "Purchase Order ID:";
            // 
            // lblnotes
            // 
            this.lblnotes.AutoSize = true;
            this.lblnotes.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tBLINVOICEBindingSource3, "invoiceID", true));
            this.lblnotes.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tBLINVOICEBindingSource3, "info", true));
            this.lblnotes.Location = new System.Drawing.Point(109, 104);
            this.lblnotes.Name = "lblnotes";
            this.lblnotes.Size = new System.Drawing.Size(49, 20);
            this.lblnotes.TabIndex = 28;
            this.lblnotes.Text = "notes";
            // 
            // lblpay
            // 
            this.lblpay.AutoSize = true;
            this.lblpay.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tBLINVOICEBindingSource3, "invoiceID", true));
            this.lblpay.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tBLINVOICEBindingSource3, "due_date", true));
            this.lblpay.Location = new System.Drawing.Point(158, 74);
            this.lblpay.Name = "lblpay";
            this.lblpay.Size = new System.Drawing.Size(75, 20);
            this.lblpay.TabIndex = 27;
            this.lblpay.Text = "dd/mm/yy";
            // 
            // lblcreated
            // 
            this.lblcreated.AutoSize = true;
            this.lblcreated.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.tBLINVOICEBindingSource3, "invoiceID", true));
            this.lblcreated.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.tBLINVOICEBindingSource3, "created_date", true));
            this.lblcreated.Location = new System.Drawing.Point(156, 51);
            this.lblcreated.Name = "lblcreated";
            this.lblcreated.Size = new System.Drawing.Size(75, 20);
            this.lblcreated.TabIndex = 25;
            this.lblcreated.Text = "dd/mm/yy";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(29, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 20);
            this.label13.TabIndex = 24;
            this.label13.Text = "Notes:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(28, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 20);
            this.label11.TabIndex = 22;
            this.label11.Text = "Pay Due Date:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 20);
            this.label10.TabIndex = 21;
            this.label10.Text = "Created Date:";
            // 
            // invoicetxt
            // 
            this.invoicetxt.Enabled = false;
            this.invoicetxt.Location = new System.Drawing.Point(8, 7);
            this.invoicetxt.Name = "invoicetxt";
            this.invoicetxt.Size = new System.Drawing.Size(100, 26);
            this.invoicetxt.TabIndex = 20;
            this.invoicetxt.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // tBLINVOICEBindingSource1
            // 
            this.tBLINVOICEBindingSource1.DataMember = "TBL_INVOICE";
            this.tBLINVOICEBindingSource1.DataSource = this.accountsPayableDataSet1;
            // 
            // tBLINVOICEBindingSource2
            // 
            this.tBLINVOICEBindingSource2.DataMember = "TBL_INVOICE";
            this.tBLINVOICEBindingSource2.DataSource = this.accountsPayableDataSet1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(32, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 25);
            this.label5.TabIndex = 19;
            this.label5.Text = "Invoice:";
            // 
            // approvecmd
            // 
            this.approvecmd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.approvecmd.Location = new System.Drawing.Point(802, 841);
            this.approvecmd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.approvecmd.Name = "approvecmd";
            this.approvecmd.Size = new System.Drawing.Size(136, 46);
            this.approvecmd.TabIndex = 39;
            this.approvecmd.Text = "Approve";
            this.approvecmd.UseVisualStyleBackColor = true;
            this.approvecmd.Click += new System.EventHandler(this.approvecmd_Click);
            // 
            // tBLINVOICEBindingSource
            // 
            this.tBLINVOICEBindingSource.DataMember = "TBL_INVOICE";
            this.tBLINVOICEBindingSource.DataSource = this.accountsPayableDataSet1;
            // 
            // tBL_INVOICETableAdapter
            // 
            this.tBL_INVOICETableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(28, 256);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(913, 573);
            this.dataGridView1.TabIndex = 51;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(376, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 52;
            this.label1.Text = "Status:";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Enabled = false;
            this.radioButton1.Location = new System.Drawing.Point(452, 50);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(102, 24);
            this.radioButton1.TabIndex = 53;
            this.radioButton1.Text = "Approved";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(452, 82);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(131, 24);
            this.radioButton2.TabIndex = 54;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Not Approved";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // ViewInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 895);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.approvecmd);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ViewInvoice";
            this.Text = "View Invoice";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ViewInvoice_FormClosing);
            this.Load += new System.EventHandler(this.ViewInvoice_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.accountsPayableDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLINVOICEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lblsurname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblnotes;
        private System.Windows.Forms.Label lblpay;
        private System.Windows.Forms.Label lblcreated;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox invoicetxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button approvecmd;
        private System.Windows.Forms.LinkLabel lblpoid;
        private System.Windows.Forms.Label label40;
        private AccountsPayableDataSet1 accountsPayableDataSet1;
        private System.Windows.Forms.BindingSource tBLINVOICEBindingSource;
        private AccountsPayableDataSet1TableAdapters.TBL_INVOICETableAdapter tBL_INVOICETableAdapter;
        private System.Windows.Forms.BindingSource tBLINVOICEBindingSource1;
        private System.Windows.Forms.BindingSource tBLINVOICEBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblcountry;
        private System.Windows.Forms.BindingSource tBLINVOICEBindingSource3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}