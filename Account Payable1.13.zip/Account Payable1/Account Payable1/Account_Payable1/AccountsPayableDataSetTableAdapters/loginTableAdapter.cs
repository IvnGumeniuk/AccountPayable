﻿namespace Account_Payable1.AccountsPayableDataSetTableAdapters
{
    internal class loginTableAdapter
    {
    }
}